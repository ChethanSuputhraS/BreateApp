//
//  ChestDeviceCell.swift
//  BreathingApp
//
//  Created by Ashwin on 2/3/20.
//  Copyright © 2020 Ashwin. All rights reserved.
//

import UIKit

class ChestDeviceCell: UITableViewCell
{
    let lblChestDevice = UILabel()
    let lblAbdomenDevice = UILabel()
    override func awakeFromNib()
    {
        super.awakeFromNib()
        // Initialization code
    }

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?)
      {
          super.init(style: style, reuseIdentifier: reuseIdentifier)
           // Initialization code
        
        
        lblChestDevice.frame = CGRect(x: 10, y: 0, width: GlobalVariables.Device_Width-20, height: 50)
        lblChestDevice.textColor = UIColor.white
        self.contentView.addSubview(lblChestDevice)
        
        
                let lblBGLine = UILabel()
                lblBGLine.frame = CGRect(x: 0, y: 50, width: GlobalVariables.Device_Width-40, height: 10)
                lblBGLine.backgroundColor = UIColor.init(red: 5.0/255, green: 56.0/255, blue: 83.0/255, alpha: 1)
                lblBGLine.layer.cornerRadius = 26
                self.contentView.addSubview(lblBGLine)
        
        
        lblAbdomenDevice.frame = CGRect(x: 10, y: 0, width: GlobalVariables.Device_Width-20, height: 50)
          lblAbdomenDevice.textColor = UIColor.white
          self.contentView.addSubview(lblAbdomenDevice)
        
        
        
        
        
        
        
    
    }
       required init?(coder: NSCoder) {
           fatalError("init(coder:) has not been implemented")
       }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
