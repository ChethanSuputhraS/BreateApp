//
//  RecordVC.swift
//  BreathingApp
//
//  Created by stuart watts on 12/02/2020.
//  Copyright © 2020 Ashwin. All rights reserved.
//

import UIKit
import CoreBluetooth

var bodyBackView = UIView()
var btnBack = UIButton()
var lineChart: LineChart!
var listPeripheralsConnected = stretchsenseObject.getListPeripheralsConnected()
var numberOfSample = stretchsenseObject.numberOfSample
var numberOfThePeripheralToUpdate = 0
var valueAverage : UInt8 = 0
var newConnection : Bool = false
var previousNumberOfPeripheral = 0
var defaultValueOfTheNewSensor : CGFloat = 0
var timestampSampleRelativeTime = 0.0
var startTime = TimeInterval()



class RecordVC: UIViewController
{
    var sampleNumber = 0
    var isRecording = false
    var sentenceToRecord = ""
    var allSentencesRecorded : [String] = []
    var view2 =  UIView()
    var circleChest : UILabel!
    var circleAbdome : UILabel!
    var circlView : UIView!
    
    //css
    let buttonViewBottom = UIView()
    let btnRaw = UIButton()
    let btnTimer = UIButton()
    let btnSmooth = UIButton()
    let btnVisual = UIButton()
    let imgViewRaw = UIImageView()
    let imgViewSmooth = UIImageView()
    let imgViewVisual = UIImageView()
    let viewSessionTime = UIView()


    var btnGraphTouch = UIButton()
    var AlertViewSavedata = UIView()
    var btnEndSessionAndSave = UIButton()
    var btnContinueSession = UIButton()
    
    var lblTime = UILabel()
    var count1 = 01
    var timer : Timer?

    override func viewDidLoad()
    {
        isRecording = true
        let defaultCenter = NotificationCenter.default
        defaultCenter.addObserver(self, selector: #selector(newValueDetected), name: NSNotification.Name(rawValue: "UpdateValueNotification"),object: nil)
        defaultCenter.addObserver(self, selector: #selector(self.newInfoDetected), name: NSNotification.Name(rawValue: "UpdateInfo"),object: nil)

        
        let listPeripheralsAvailable = stretchsenseObject.getListPeripheralsAvailable()
        for i in 0...listPeripheralsAvailable.count-1
        {
            let p  =  listPeripheralsAvailable[i]
           
               
            stretchsenseObject.discoverServicesforPeripherals(periph: p!)
        }

        self.navigationController?.isNavigationBarHidden = true
        self.view.backgroundColor = UIColor.init(red: 13.0/255, green: 42.0/255, blue: 67.0/255, alpha: 1)
        
        bodyBackView.frame = CGRect(x: 0, y: 0, width: constants.widths, height: constants.heighs)
        self.view.addSubview(bodyBackView)
        
        btnBack.frame = CGRect(x: 0, y: 10, width: 50, height: 65)
        btnBack.setTitleColor(.white, for: .normal)
        btnBack.addTarget(self, action: #selector(btnBackClick), for: .touchUpInside)
        btnBack.setImage(UIImage.init(named: "back.png"), for: .normal)
        bodyBackView.addSubview(btnBack)

        btnTimer.frame = CGRect(x: constants.widths-40, y: 25, width: 20, height: 35)
        btnTimer.setTitleColor(.white, for: .normal)
        btnTimer.addTarget(self, action: #selector(btnTimerClick), for: .touchUpInside)
        btnTimer.setImage(UIImage.init(named: "timer.png"), for: .normal)
        self.view.addSubview(btnTimer)
        
        self.view2.frame = CGRect(x: 0, y: 200, width: 375, height: 320)
        self.view.addSubview(self.view2)
        var views: [String: AnyObject] = [:]
        lineChart = LineChart()
        lineChart.area = true
        lineChart.x.grid.count = 1
        lineChart.y.grid.count = 1
        lineChart.autoMinMax = false
        lineChart.translatesAutoresizingMaskIntoConstraints = true
        self.view2.addSubview(lineChart)
        
        lineChart.frame = CGRect(x: 0, y: 0, width: 375, height: 320)
        views["chart"] = lineChart
        
        // css
        
        btnGraphTouch.frame = CGRect(x: 0, y: 200, width: self.view.frame.width, height: self.view.frame.height-250)
        btnGraphTouch.addTarget(self, action: #selector(btnGraphTouchClick), for: .touchUpInside)
        btnGraphTouch.backgroundColor = UIColor.clear
        
        self.view.addSubview(btnGraphTouch)
        
        buttonViewBottom.frame = CGRect(x: 0, y: self.view.frame.height-70, width: self.view.frame.width, height: 70)
           buttonViewBottom.backgroundColor = UIColor.clear
           self.view.addSubview(buttonViewBottom)
           
           let btnWidth = self.view.frame.width/3

           
           imgViewRaw.frame = CGRect(x: (btnWidth-30)/2, y: 15, width: 35, height: 30)
           imgViewRaw.image = UIImage.init(named: "Raw.png")
           buttonViewBottom.addSubview(imgViewRaw)

           btnRaw.frame = CGRect(x: 0, y: 0, width: btnWidth, height: 70)
           btnRaw.backgroundColor = UIColor.clear
           btnRaw.setTitle("raw", for: .normal)
           btnRaw.setTitleColor(.lightGray, for: .normal)
           btnRaw.contentVerticalAlignment = UIControl.ContentVerticalAlignment.bottom
           btnRaw.addTarget(self, action: #selector(btnRawClick), for: .touchUpInside)
           buttonViewBottom.addSubview(btnRaw)
           
          
           imgViewSmooth.frame = CGRect(x: btnWidth + ((btnWidth-30)/2), y: 10, width: 40, height: 35)
           imgViewSmooth.image = UIImage.init(named: "Smooth.png")
           buttonViewBottom.addSubview(imgViewSmooth)

           btnSmooth.frame = CGRect(x: btnWidth, y: 0, width: btnWidth, height: 70)
           btnSmooth.setTitle("smooth", for: .normal)
           btnSmooth.setTitleColor(.lightGray, for: .normal)
           btnSmooth.backgroundColor = UIColor.clear
           btnSmooth.contentVerticalAlignment = UIControl.ContentVerticalAlignment.bottom
           btnSmooth.addTarget(self, action: #selector(btnSmoothClick), for: .touchUpInside)
           buttonViewBottom.addSubview(btnSmooth)
           
        
           imgViewVisual.frame = CGRect(x: (btnWidth * 2) + ((btnWidth-30)/2), y: 10, width: 30, height: 30)
           imgViewVisual.image = UIImage.init(named: "Visual.png")
           buttonViewBottom.addSubview(imgViewVisual)

           btnVisual.frame = CGRect(x: btnWidth*2, y: 0, width: btnWidth, height: 70)
           btnVisual.setTitle("visual", for: .normal)
           btnVisual.setTitleColor(.lightGray, for: .normal)
           btnVisual.addTarget(self, action: #selector(btnVisualClick), for: .touchUpInside)
           btnVisual.backgroundColor = UIColor.clear
           btnVisual.contentVerticalAlignment = UIControl.ContentVerticalAlignment.bottom
           buttonViewBottom.addSubview(btnVisual)
           
           viewSessionTime.frame = CGRect(x: 25, y: 70, width: self.view.frame.width-50, height: 80)
           viewSessionTime.backgroundColor = UIColor.init(red: 22.0/255, green: 68.0/255, blue: 93.0/255, alpha: 1)
           viewSessionTime.layer.cornerRadius = 44
           self.view.addSubview(viewSessionTime)
           
           let lblChest = UILabel()
           lblChest.frame = CGRect(x: 50, y: 10, width: 100, height: 30)
           lblChest.text = "Chest"
           lblChest.textColor = .white
           viewSessionTime.addSubview(lblChest)
                 
           let lblAbdomen = UILabel()
           lblAbdomen.frame = CGRect(x: 50, y: 40, width: 100, height: 30)
           lblAbdomen.text = "Abdomen"
           lblAbdomen.textColor = .white
           viewSessionTime.addSubview(lblAbdomen)
           
           let lblSession = UILabel()
           lblSession.frame = CGRect(x: 190, y: 10, width: 100, height: 30)
           lblSession.text = "Session Time"
           lblSession.font = UIFont.boldSystemFont(ofSize: 15)
           lblSession.textColor = .white
           viewSessionTime.addSubview(lblSession)
        
           
        
           lblTime.frame = CGRect(x: 190, y: 40, width: 150, height: 30)
           lblTime.text = "00:00"
           lblTime.textColor = .white
           lblTime.font = UIFont.boldSystemFont(ofSize: 35)
           viewSessionTime.addSubview(lblTime)
           
           let lblYellowRing = UILabel()
           lblYellowRing.frame = CGRect(x: 20, y: 45, width: 20, height: 20)
           lblYellowRing.layer.borderWidth = 3
           lblYellowRing.layer.cornerRadius = 10
           lblYellowRing.layer.borderColor = UIColor.yellow.cgColor
           viewSessionTime.addSubview(lblYellowRing)
           
           let lblBlueRing = UILabel()
           lblBlueRing.frame = CGRect(x: 20, y: 15, width: 20, height: 20)
           lblBlueRing.layer.borderWidth = 3
           lblBlueRing.layer.cornerRadius = 10
           lblBlueRing.layer.borderColor = UIColor.init(red: 106.0/255, green: 227.0/255, blue: 255.0/255, alpha: 1).cgColor
           viewSessionTime.addSubview(lblBlueRing)
        
    timer = Timer.scheduledTimer(timeInterval: 1.0,
                                     target: self,
                                     selector: #selector(timerAction),
                                     userInfo: nil,
                                     repeats: true)
        
        AlertViewSavedata.frame = CGRect(x: 20, y: self.view.frame.height, width: self.view.frame.width-40, height: 200)
        AlertViewSavedata.backgroundColor = UIColor.init(red: 25.0/255, green: 78.0/255, blue: 107.0/255, alpha: 0.3)
        AlertViewSavedata.layer.cornerRadius = 25
        self.view.addSubview(AlertViewSavedata)
        
        btnEndSessionAndSave.frame = CGRect(x: 20, y: 40, width: 300, height: 50)
        btnEndSessionAndSave.backgroundColor = UIColor.init(red: 87.0/255, green: 155.0/255, blue: 191.0/255, alpha: 1)
        btnEndSessionAndSave.addTarget(self, action: #selector(btnEndSessinClick), for: .touchUpInside)
        btnEndSessionAndSave.setTitle("End session & Save data", for: .normal)
        btnEndSessionAndSave.setTitleColor(.white, for: .normal)
        btnEndSessionAndSave.layer.cornerRadius = 26
        AlertViewSavedata.addSubview(btnEndSessionAndSave)
        
        btnContinueSession.frame = CGRect(x: 20, y: 110, width: 300, height: 50)
        btnContinueSession.backgroundColor = UIColor.init(red: 87.0/255, green: 155.0/255, blue: 191.0/255, alpha: 1)
        btnContinueSession.addTarget(self, action: #selector(btnContinueSessionClick), for: .touchUpInside)
        btnContinueSession.setTitle("Continue Session", for: .normal)
        btnContinueSession.setTitleColor(.white, for: .normal)
        btnContinueSession.layer.cornerRadius = 26
        AlertViewSavedata.addSubview(btnContinueSession)
        
        
        
        
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    //MARK:- Buttons
    
    @objc func btnBackClick()
    {
//        self.navigationController?.popViewController(animated: true)
    }
    @objc func newInfoDetected()
    {
        listPeripheralsConnected = stretchsenseObject.getListPeripheralsConnected()
    }
    @objc func btnRawClick()
     {
        
        imgViewRaw.image = UIImage.init(named: "RawSelected.png")
        btnRaw.setTitleColor(.white, for: .normal)
        imgViewSmooth.image = UIImage.init(named: "Smooth.png")
        btnSmooth.setTitleColor(.lightGray, for: .normal)
        imgViewVisual.image = UIImage.init(named: "Visual.png")
        btnVisual.setTitleColor(.lightGray, for: .normal)
        
        view2.isHidden = false
//        smoothView.isHidden = true
//        visualview.isHidden = true
        
    }

    @objc func btnSmoothClick()
    {
        imgViewSmooth.image = UIImage.init(named: "SmoothSelected.png")
                    btnSmooth.setTitleColor(.white, for: .normal)
              
        imgViewVisual.image = UIImage.init(named: "Visual.png")
        btnVisual.setTitleColor(.lightGray, for: .normal)
        
        imgViewRaw.image = UIImage.init(named: "Raw.png")
        btnRaw.setTitleColor(.lightGray, for: .normal)
      
        view2.isHidden = true
//        smoothView.isHidden = false
//        visualview.isHidden = true
    }
    @objc func btnVisualClick()
    {
        imgViewVisual.image = UIImage.init(named: "VisualSelected.png")
        btnVisual.setTitleColor(.white, for: .normal)
        
        imgViewSmooth.image = UIImage.init(named: "Smooth.png")
        btnSmooth.setTitleColor(.lightGray, for: .normal)
        
        imgViewRaw.image = UIImage.init(named: "Raw.png")
        btnRaw.setTitleColor(.lightGray, for: .normal)
        
//        visualview.isHidden = false
          view2.isHidden = true
//        smoothView.isHidden = true
        
    }
    @objc func btnGraphTouchClick()
    {
        buttonViewBottom.isHidden = true
        viewSessionTime.isHidden = true
        btnBack.isHidden = true
        btnTimer.isHidden = true
        
        timer?.invalidate()
        UIView.transition(with: AlertViewSavedata, duration: 0.5, options: .curveEaseIn, animations:
            { self.AlertViewSavedata.frame = CGRect(x: 20, y: (self.view.frame.height-200)/2, width: self.view.frame.width-40, height: 200)
                }, completion: {( finished: Bool) -> () in
                
                 })
    }
    @objc func btnEndSessinClick()
     {
        let formatter = DateFormatter()
                   // initially set the format based on your datepicker date
                   formatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
                   let myString = formatter.string(from: Date())
                   print(myString)
                   
                   //let exportFilePath = NSTemporaryDirectory() + "StretchSense_Record.csv"
                   let exportFilePath = NSTemporaryDirectory() + "StretchSense_" + "\(myString)" + ".csv"
                   let exportFileURL = URL(fileURLWithPath: exportFilePath)
                   FileManager.default.createFile(atPath: exportFilePath, contents: Data(), attributes: nil)
                   //var fileHandleError: NSError? = nil
                   var fileHandle: FileHandle? = nil
                   do {
                       fileHandle = try FileHandle(forWritingTo: exportFileURL)
                   } catch {
                       print( "Error with fileHandle")
                   }
                   
                   if fileHandle != nil {
                       fileHandle!.seekToEndOfFile()
                       let nsdataToShare: Data = stringArrayToNSData(allSentencesRecorded)
                       
                       fileHandle!.write(/*csvData!*/ nsdataToShare)
                       
                       fileHandle!.closeFile()
        }
        // Item to share
                    let firstActivityItem = URL(fileURLWithPath: exportFilePath)
                    
                    // Create share activity view controller and give the csv file
                    let activityViewController: UIActivityViewController = UIActivityViewController(activityItems: [firstActivityItem], applicationActivities: nil)
                    
                        self.present(activityViewController, animated: true, completion: nil)
     }
     @objc func btnContinueSessionClick()
     {
         buttonViewBottom.isHidden = false
         viewSessionTime.isHidden = false
         
     UIView.transition(with: AlertViewSavedata, duration: 0.5, options: .curveEaseIn, animations:
         { self.AlertViewSavedata.frame = CGRect(x: 20, y: self.view.frame.height, width: self.view.frame.width-40, height: 200)
         
          self.timer?.invalidate()
         self.timer = Timer.scheduledTimer(timeInterval: 1.0,target: self,
                                                                 selector: #selector(self.timerAction),
                                                                 userInfo: nil,
                                                                 repeats: true)
         }, completion: {( finished: Bool) -> () in
         
          })
     }
    @objc func btnTimerClick()
    {
        
    }
    @objc func timerAction()
    {
        if(count1 > 0)
        {
            if count1 != 0
            {
                count1 += 1
            }
            else
            {
            if let timer = self.timer
                {
                    timer.invalidate()
                    self.timer = nil
                }
            }
            self.lblTime.text = self.timeFormatted(self.count1)
        }

    }
    func timeFormatted(_ totalSeconds: Int) -> String
    {
        let seconds: Int = totalSeconds % 60
        let minutes: Int = (totalSeconds / 60) % 60
        return String(format: "%02d:%02d", minutes, seconds)
    }
    
    @objc func newValueDetected()
    {
//        print("new value detected")
        listPeripheralsConnected = stretchsenseObject.getListPeripheralsConnected()
        ask_new_data()
    }
    func ask_new_data()
    {
        listPeripheralsConnected = stretchsenseObject.getListPeripheralsConnected()
        reloadGraph()
        
            if sampleNumber == 0
            {
                startTime = NSDate.timeIntervalSinceReferenceDate
                sentenceToRecord = "Sequence, Sample Number, Time, Sensor Value"
                allSentencesRecorded.append(sentenceToRecord)
            }
            sampleNumber += 1
            if (timestampSampleRelativeTime < 0)
            {
                timestampSampleRelativeTime = 0.0
            }
            else
            {
                timestampSampleRelativeTime = NSDate.timeIntervalSinceReferenceDate - startTime
            }
            // The sentence type is: sample number, time, capacitanceSensor1, capacitanceSensor2...
            sentenceToRecord = "\n" + String(Int(0)) + ", " + String(sampleNumber) + ", " + String(timestampSampleRelativeTime)
            
            for myPeripheralConnected in listPeripheralsConnected
            {
                let rawValueFromThePeripheral = myPeripheralConnected.previousValueRawFromTheSensor[myPeripheralConnected.previousValueRawFromTheSensor.count-1]
                let realValueFromThePeripheral = Int(rawValueFromThePeripheral /** 0.1*/)
                sentenceToRecord += ", " + "\(realValueFromThePeripheral)"
            }
            allSentencesRecorded.append(sentenceToRecord)
    }
    func stringArrayToNSData(_ array: [String]) -> Data {
        print("stringArrayToNSData()")
        
        let data = NSMutableData()
        let terminator = [0]
        for string in array {
            if let encodedString = string.data(using: String.Encoding.utf8) {
                data.append(encodedString)
                data.append(terminator, length: 1)
            }
            else {
                NSLog("Cannot encode string \"\(string)\"")
            }
        }
        return data as Data
    }
    
    func reloadGraph()
    {
        lineChart.clear()
//        self.view2.frame = CGRect(x: 0, y: 200, width: 375, height: 300)
//        lineChart.frame = CGRect(x: 0, y: 0, width: 375, height: 300)
        if listPeripheralsConnected.count != 0
        {
            for myPeripheralConnected in listPeripheralsConnected
            {
                let strChestUUID  = String(format: "%@", UserDefaults.standard.value(forKey: "ChestUUID") as! CVarArg)
                let strAbdomenUUID = String(format: "%@", UserDefaults.standard.value(forKey: "AbdomenUUID") as! CVarArg)
                if myPeripheralConnected.display == true
                {
                    let strUUID = myPeripheralConnected.uuid as String
                    var strType : Int =  1
                    
                    if strUUID == strChestUUID
                    {
                        strType = 0
                    }
                    else if strUUID == strAbdomenUUID
                    {
                        strType = 1
                    }
                    if isCircleAvail
                    {
                        if myPeripheralConnected.value != 0.0
                        {
                            var intVal : CGFloat = CGFloat(myPeripheralConnected.value - 280)
                            if intVal > 0
                            {
                                if intVal > 80
                                {
                                    intVal  = intVal / 5.0
                                }
                                UIView.animate(withDuration: Double(0.5), animations: {
                                    
                                    if strType == 0
                                    {
                                        var chestRect : CGRect = self.circleChest.frame
                                        let vwithd = CGFloat(300 + (intVal))
                                        chestRect.size.width = vwithd
                                        chestRect.size.height = vwithd
                                        chestRect.origin.x = CGFloat((self.circlView.frame.width - vwithd)/2)
                                        chestRect.origin.y = CGFloat((self.circlView.frame.width - vwithd)/2)
                                        self.circleChest.frame = chestRect
                                        self.circleChest.layer.cornerRadius = chestRect.size.height/2
                                    }
                                    else
                                    {
                                        var chestRect : CGRect = self.circleChest.frame
                                        let vwithd = CGFloat(300 + (intVal))
                                        chestRect.size.width = vwithd
                                        chestRect.size.height = vwithd
                                        chestRect.origin.x = CGFloat((self.circlView.frame.width - vwithd)/2)
                                        chestRect.origin.y = CGFloat((self.circlView.frame.width - vwithd)/2)
                                        self.circleChest.frame = chestRect
                                        self.circleChest.layer.cornerRadius = chestRect.size.height/2
                                    }
                                })
                            }
                            else
                            {
                            }
                        }
                    }
                    else
                    {
                        lineChart.addLine(myPeripheralConnected.previousValueAveraged, colorNumber: strType)
                    }
                }
            }
        }
    }
    func didSelectDataPoint(_ x: CGFloat, yValues: Array<CGFloat>)
    {
        
    }
    @objc func recordPauseButton(_ sender: AnyObject)
    {
        print("button : record/pause")
        if listPeripheralsConnected.count == 0
        {
            print("button : record/pause - No Periph")
        }
        else
        {
            print("button : record/pause - Periph Detected")
            if isRecording == true
            {
                print("button : record/pause - Periph Detected - is recording")
                isRecording = false
                UIApplication.shared.isIdleTimerDisabled = false
            }
            else
            {
                print("button : record/pause - Periph Detected - is not recording")
                isRecording = true
                UIApplication.shared.isIdleTimerDisabled = true
            }
        }
    }
    @objc func deleteRecord(_ sender: AnyObject)
    {
        if listPeripheralsConnected.count == 0
        {
        }
        else
        {
            if isRecording == true
            {
//                self.labelRecord.text = "Stop Recording First"
            }
            else
            {
                // If the system is not recording, ask for permission to delete the data recorded
                let refreshAlert = UIAlertController(title: "Delete", message: "Are you sure you want to delete all recorded data? ", preferredStyle: UIAlertController.Style.alert)
                refreshAlert.addAction(UIAlertAction(title: "Confirm", style: .default, handler: { (action: UIAlertAction!) in
                    self.allSentencesRecorded = []
                    self.sampleNumber = 0
                }))
                refreshAlert.addAction(UIAlertAction(title: "Cancel", style: .default, handler: { (action: UIAlertAction!) in
                }))
                present(refreshAlert, animated: true, completion: nil)
            }
        }
    }

    // MARK: - Navigation


}
