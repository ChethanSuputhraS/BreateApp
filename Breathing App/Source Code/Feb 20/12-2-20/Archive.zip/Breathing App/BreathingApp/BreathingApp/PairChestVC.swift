//
//  PairChestVC.swift
//  BreathingApp
//
//  Created by Ashwin on 2/1/20.
//  Copyright © 2020 Ashwin. All rights reserved.
//

import UIKit

class PairChestVC: UIViewController,UITableViewDelegate,UITableViewDataSource
{
    let lblPairViewAbdomen = UILabel()
    let animBtnViewAbdomen = UIView()
    let imgViewbody = UIImageView()
    let pairChestButton = UIButton()
    let btnPairChest = UIButton()
    let tblChestDevice = UITableView()
    var arrayChestDevice :  Array<Any> = []
    var arrayAbdomenDevice :  Array<Any> = []
    let ChestPairView = UIView()
    let AbdomenPairView = UIView()
    let btnBack = UIButton()
    let lblPairChest = UILabel()
    let imgViewChest = UIImageView()
    let imgViewAbdomen = UIImageView()
    let BtnViewAnimation = UIView()
    let animBtnView = UIView()
    let lblPairViewChest = UILabel()
    let btnNext = UIButton()
    let btnBackAbdomen = UIButton()
    let btnPairAbdomen = UIButton()
    var isTblCliked = false
    
    
    override func viewDidLoad()
    {
         self.navigationController?.isNavigationBarHidden = true
        self.view.backgroundColor = UIColor.init(red: 5.0/255, green: 56.0/255, blue: 83.0/255, alpha: 1)
        
        ChestPairView.frame = CGRect(x: 0, y: 0, width: GlobalVariables.Device_Width, height: GlobalVariables.Device_Height)
        self.view.addSubview(ChestPairView)
        
        let bodyView = UIView()
        bodyView.frame = CGRect(x: 20, y: GlobalVariables.Device_Height-600, width: GlobalVariables.Device_Width-40, height: GlobalVariables.Device_Height-300)
         bodyView.backgroundColor = UIColor.init(red: 25.0/255, green: 78.0/255, blue: 107.0/255, alpha: 1)
        ChestPairView.addSubview(bodyView)
        
        imgViewbody.frame = CGRect(x: 45, y: 60, width: 250, height: 250)
        imgViewbody.image = UIImage.init(named: "Component 3 – 8@2x.png")
        bodyView.addSubview(imgViewbody)
        
        let lblChestPair = UILabel()
        lblChestPair.frame = CGRect(x: 0, y: 0, width: GlobalVariables.Device_Width-50, height: 50)
        lblChestPair.text = "Place Chest strap arround \n  chest at tip of sternum"
        lblChestPair.textAlignment = .center
        lblChestPair.textColor = UIColor.white
        lblChestPair.numberOfLines = 0
        bodyView.addSubview(lblChestPair)
        
        let lblChestPullStrap = UILabel()
        lblChestPullStrap.frame = CGRect(x: 0, y:310, width: GlobalVariables.Device_Width-50, height: 50)
        lblChestPullStrap.text = "Exhale and pull strap snug"
        lblChestPullStrap.textAlignment = .center
        lblChestPullStrap.textColor = UIColor.white
        lblChestPullStrap.numberOfLines = 0
        bodyView.addSubview(lblChestPullStrap)
        

        
        
        btnPairChest.frame = CGRect(x: 50, y: GlobalVariables.Device_Height-150, width: GlobalVariables.Device_Width-100, height: 50)
        btnPairChest.setTitle("Pair Chest Strap", for: .normal)
        btnPairChest.setTitleColor(.white, for: .normal)
        btnPairChest.addTarget(self, action: #selector(btnPairChestClick), for: .touchUpInside)
        btnPairChest.titleLabel?.font = UIFont.boldSystemFont(ofSize: 20)
        btnPairChest.layer.cornerRadius = 26
        btnPairChest.backgroundColor = UIColor.init(red: 85.0/255, green: 116.0/255, blue: 132.0/255, alpha: 1)
        ChestPairView.addSubview(btnPairChest)
        
        
        tblChestDevice.frame = CGRect(x: 20, y: GlobalVariables.Device_Height, width: GlobalVariables.Device_Width-40, height: GlobalVariables.Device_Height)
        tblChestDevice.delegate = self
        tblChestDevice.dataSource = self
        tblChestDevice.backgroundColor = UIColor.clear
            tblChestDevice.register(ChestDeviceCell.self, forCellReuseIdentifier: "CellChestDevice")
       ChestPairView.addSubview(tblChestDevice)
        
       
        btnBack.frame = CGRect(x: 10, y: 20, width: 50, height: 50)
        btnBack.setTitle("Back", for: .normal)
        btnBack.setTitleColor(.white, for: .normal)
        btnBack.addTarget(self, action: #selector(btnBackClick), for: .touchUpInside)
        ChestPairView.addSubview(btnBack)
        
        btnNext.frame = CGRect(x: 20, y: GlobalVariables.Device_Height-50, width: GlobalVariables.Device_Width-40, height: 50)
        btnNext.setTitle("Next ->", for: .normal)
        btnNext.setTitleColor(.white, for: .normal)
        btnNext.addTarget(self, action: #selector(btnNextClick), for: .touchUpInside)
        btnNext.titleLabel?.font = UIFont.boldSystemFont(ofSize: 25)
        btnNext.isHidden = true
        ChestPairView.addSubview(btnNext)
        
        
        
        //Abdamen view
        
        
        AbdomenPairView.frame = CGRect(x: 0, y: 0, width: GlobalVariables.Device_Width, height: GlobalVariables.Device_Height)
        AbdomenPairView.backgroundColor = UIColor.init(red: 5.0/255, green: 56.0/255, blue: 83.0/255, alpha: 1)
        AbdomenPairView.isHidden = true
        self.view.addSubview(AbdomenPairView)
        
        let bodyViewAbdemen = UIView()
        bodyViewAbdemen.frame = CGRect(x: 20, y: GlobalVariables.Device_Height-600, width: GlobalVariables.Device_Width-40, height: GlobalVariables.Device_Height-300)
         bodyViewAbdemen.backgroundColor = UIColor.init(red: 25.0/255, green: 78.0/255, blue: 107.0/255, alpha: 1)
        AbdomenPairView.addSubview(bodyViewAbdemen)
        
        let imgViewabdmen = UIImageView()
        imgViewabdmen.frame = CGRect(x: 45, y: 60, width: 250, height: 250)
        imgViewabdmen.image = UIImage.init(named: "body_strap_2@2x.png")
        bodyViewAbdemen.addSubview(imgViewabdmen)
        
        let lblAbdamenPair = UILabel()
        lblAbdamenPair.frame = CGRect(x: 0, y: 0, width: GlobalVariables.Device_Width-50, height: 50)
        lblAbdamenPair.text = "Place abdomen strap arround \n  chest at tip of navel!"
        lblAbdamenPair.textAlignment = .center
        lblAbdamenPair.textColor = UIColor.white
        lblAbdamenPair.numberOfLines = 0
        bodyViewAbdemen.addSubview(lblAbdamenPair)
        
        let lblAbdomenPullStrap = UILabel()
        lblAbdomenPullStrap.frame = CGRect(x: 0, y:310, width: GlobalVariables.Device_Width-50, height: 50)
        lblAbdomenPullStrap.text = "Exhale and pull strap snug"
        lblAbdomenPullStrap.textAlignment = .center
        lblAbdomenPullStrap.textColor = UIColor.white
        lblAbdomenPullStrap.numberOfLines = 0
        bodyViewAbdemen.addSubview(lblAbdomenPullStrap)
        
        btnBackAbdomen.frame = CGRect(x: 10, y: 20, width: 50, height: 50)
        btnBackAbdomen.setTitle("Back", for: .normal)
        btnBackAbdomen.setTitleColor(.white, for: .normal)
        btnBackAbdomen.addTarget(self, action: #selector(btnAbdomenBackClick), for: .touchUpInside)
        AbdomenPairView.addSubview(btnBackAbdomen)
        
        
        btnPairAbdomen.frame = CGRect(x: 50, y: GlobalVariables.Device_Height-150, width: GlobalVariables.Device_Width-100, height: 50)
        btnPairAbdomen.setTitle("Pair Abdomen Strap", for: .normal)
        btnPairAbdomen.setTitleColor(.white, for: .normal)
        btnPairAbdomen.addTarget(self, action: #selector(btnPairAbdomenClick), for: .touchUpInside)
        btnPairAbdomen.titleLabel?.font = UIFont.boldSystemFont(ofSize: 20)
        btnPairAbdomen.layer.cornerRadius = 26
        btnPairAbdomen.backgroundColor = UIColor.init(red: 85.0/255, green: 116.0/255, blue: 132.0/255, alpha: 1)
        AbdomenPairView.addSubview(btnPairAbdomen)
        

        
        
        arrayChestDevice = ["chest Device I D"," I D----","I D----"]
        arrayAbdomenDevice = ["Abdomen ID","Abdomen Device","----","---"]
        
        
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
//MARK: - Buttons Chest pair

 @objc func btnPairChestClick()
 {

            imgViewChest.isHidden = false
            tblChestDevice.frame = CGRect(x: 20, y: GlobalVariables.Device_Height-200, width: GlobalVariables.Device_Width-40, height: GlobalVariables.Device_Height)
    }
    @objc func btnBackClick()
    {
        self.navigationController?.popViewController(animated: true)
    }
    @objc func btnNextClick()
    {
        AbdomenPairView.isHidden = false
        btnBackAbdomen.isHidden = false
        
    }
    //MARK: - TableView Deligate
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
          if tableView == tblChestDevice
    {
          return 55
        
        }
       return 0
    }
   func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
   {
    if tableView == tblChestDevice
    {
        return arrayChestDevice.count
        
    }
    return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        if tableView == tblChestDevice
        {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CellChestDevice", for: indexPath) as! ChestDeviceCell
            cell.lblChestDevice.text = arrayChestDevice[indexPath.row] as? String
            cell.layer.cornerRadius = 26
            cell.backgroundColor = UIColor.init(red: 23.0/255, green: 113.0/255, blue: 147.0/255, alpha: 1)
            
            cell.selectionStyle = .none
            
             
            
            return cell
        }
        let tblDemo = UITableViewCell()
               return tblDemo
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        if tableView == tblChestDevice
        {
            if indexPath.row == 0
            {
               if isTblCliked == false
               {
                self.isTblCliked = true
                
                tblChestDevice.frame = CGRect(x: 20, y: GlobalVariables.Device_Height, width: GlobalVariables.Device_Width-40, height: GlobalVariables.Device_Height)
                
                              self.PairChest()
                              self.animationButtonChest()
                              btnNext.isHidden = false
                }
                else if isTblCliked == true
               {
                self.isTblCliked = false
                
                 tblChestDevice.frame = CGRect(x: 20, y: GlobalVariables.Device_Height, width: GlobalVariables.Device_Width-40, height: GlobalVariables.Device_Height)
                     self.PairAbdomen()
                     self.animationAbdomen()
                }
          
                
            }
            
        }
    
    }
    
    
 func PairChest()
{

    btnPairChest.isHidden = true
    btnBack.isHidden = true
    lblPairChest.isHidden = false
    
   let btnBackAbdemen = UIButton()
    btnBackAbdemen.frame = CGRect(x: 10, y: 20, width: 50, height: 50)
    btnBackAbdemen.setTitle("Back", for: .normal)
    btnBackAbdemen.addTarget(self, action: #selector(btnAbdemnBackClick), for: .touchUpInside)
    btnBackAbdemen.setTitleColor(.white, for: .normal)
    ChestPairView.addSubview(btnBackAbdemen)
   

    imgViewChest.frame = CGRect(x: GlobalVariables.Device_Width-140, y: GlobalVariables.Device_Height-150, width: 50, height: 50)
    imgViewChest.image = UIImage.init(named: "Group 7@2x.png")
    ChestPairView.addSubview(imgViewChest)
    
    }
    func PairAbdomen()
    {
        btnPairAbdomen.isHidden = true
        btnBackAbdomen.isHidden = false
        lblPairViewAbdomen.isHidden = false
        
  
        
        imgViewAbdomen.frame = CGRect(x: GlobalVariables.Device_Width-105, y: GlobalVariables.Device_Height-150, width: 50, height: 50)
        imgViewAbdomen.image = UIImage.init(named: "Group 7@2x.png")
        AbdomenPairView.addSubview(imgViewAbdomen)

    }
    
    func animationButtonChest()
    {
        animBtnView.frame = CGRect(x: 40, y: GlobalVariables.Device_Height-150, width: GlobalVariables.Device_Width-130, height: 50)
            animBtnView.backgroundColor = UIColor.init(red: 85.0/255, green: 116.0/255, blue: 132.0/255, alpha: 1)
            animBtnView.layer.cornerRadius = 26
            ChestPairView.addSubview(animBtnView)
             
            lblPairViewChest.frame = CGRect(x: 50, y: GlobalVariables.Device_Height-150, width: GlobalVariables.Device_Width-100, height: 50)
            lblPairViewChest.textColor = UIColor.white
            lblPairViewChest.text = "Pairing Chest Strap"
        lblPairViewChest.font = UIFont.boldSystemFont(ofSize: 20)
            ChestPairView.addSubview(lblPairViewChest)
        
            
            animBtnView.transform = CGAffineTransform(translationX: 0, y: 0)
                   UIView.animate(withDuration: Double(1.5), animations: {
                       self.animBtnView.alpha = 0.0
                       self.view.layoutIfNeeded()
                   })
        
            
    }
    
    func animationAbdomen()
    {
        animBtnViewAbdomen.frame = CGRect(x: 40, y: GlobalVariables.Device_Height-150, width: GlobalVariables.Device_Width-130, height: 50)
            animBtnViewAbdomen.backgroundColor = UIColor.init(red: 85.0/255, green: 116.0/255, blue: 132.0/255, alpha: 1)
            animBtnViewAbdomen.layer.cornerRadius = 26
            AbdomenPairView.addSubview(animBtnViewAbdomen)
             
            lblPairViewAbdomen.frame = CGRect(x: 50, y: GlobalVariables.Device_Height-150, width: GlobalVariables.Device_Width, height: 50)
            lblPairViewAbdomen.textColor = UIColor.white
            lblPairViewAbdomen.text = "Pairing Abdomen Strap"
            lblPairViewAbdomen.font = UIFont.boldSystemFont(ofSize: 20)
            AbdomenPairView.addSubview(lblPairViewAbdomen)
            
            animBtnViewAbdomen.transform = CGAffineTransform(translationX: 0, y: 0)
                   UIView.animate(withDuration: Double(1.5), animations: {
                       self.animBtnViewAbdomen.alpha = 0.0
                       self.view.layoutIfNeeded()
                   })
        
            
    }
  //MARK: - Buttons in Abdemn view
    @objc func btnAbdemnBackClick()
    {
        btnPairChest.isHidden = false
        lblPairChest.isHidden = true
        imgViewChest.isHidden = true
    }
    
    @objc func btnAbdomenBackClick()
    {
        ChestPairView.isHidden = false
        AbdomenPairView.isHidden = true
        lblPairViewAbdomen.isHidden = true
    }
    @objc func btnPairAbdomenClick()
    {
        btnPairAbdomen.isHidden = true
            tblChestDevice.frame = CGRect(x: 20, y: GlobalVariables.Device_Height-200, width: GlobalVariables.Device_Width-40, height: GlobalVariables.Device_Height)
        AbdomenPairView.addSubview(tblChestDevice)
    }
}
