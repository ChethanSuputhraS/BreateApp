//
//  HomeVC.swift
//  BreathingApp
//
//  Created by Ashwin on 1/30/20.
//  Copyright © 2020 Ashwin. All rights reserved.
//

import UIKit
import Alamofire


class HomeVC: UIViewController
{
    let appDelegate = UIApplication.shared.delegate as? AppDelegate
  
  
    let btnBackSession = UIButton()
    let btnRecord = UIButton()
    let btnSession = UIButton()
    let btnBackJane = UIButton()
    let btnProfile = UIButton()
    let recordView = UIView()
 
    let buttonViewBottom = UIView()
   
     
    let tblViewJaneMenu = UITableView()
  

   
    
    
    
    override func viewDidLoad()
    {
         self.navigationController?.isNavigationBarHidden = true
        self.view.backgroundColor = UIColor.init(red: 5.0/255, green: 56.0/255, blue: 83.0/255, alpha: 1)
        
        
        buttonViewBottom.frame = CGRect(x: 0, y: self.view.frame.height-70, width: self.view.frame.width, height: 70)
        buttonViewBottom.backgroundColor = UIColor.clear
        self.view.addSubview(buttonViewBottom)
        
        btnRecord.frame = CGRect(x: 0, y: 0, width: self.view.frame.width-260, height: 70)
        btnRecord.backgroundColor = UIColor.clear
        btnRecord.setTitle("Record", for: .normal)
        btnRecord.contentVerticalAlignment = UIControl.ContentVerticalAlignment.bottom

        let imgViewRecord = UIImageView()
        imgViewRecord.frame = CGRect(x: 40, y: 15, width: 30, height: 30)
        imgViewRecord.image = UIImage.init(named: "radio002 - E051@2x.png")
        buttonViewBottom.addSubview(imgViewRecord)
        
        btnRecord.addTarget(self, action: #selector(btnrecordClick), for: .touchUpInside)
        buttonViewBottom.addSubview(btnRecord)
        
         btnSession.frame = CGRect(x: self.view.frame.width-250, y: 0, width: self.view.frame.width-250, height: 70)
         btnSession.setTitle("Session", for: .normal)
         btnSession.backgroundColor = UIColor.clear
     //   btnSession.setImage(UIImage.init(named: "graph002 - E0B6.png"), for: .normal)
         btnSession.contentVerticalAlignment = UIControl.ContentVerticalAlignment.bottom
          btnSession.addTarget(self, action: #selector(btnSessionClick), for: .touchUpInside)
        
        let imgViewSession = UIImageView()
        imgViewSession.frame = CGRect(x: 170, y: 10, width: 35, height: 35)
        imgViewSession.image = UIImage.init(named: "graph002 - E0B6.png")
        buttonViewBottom.addSubview(imgViewSession)
        
         buttonViewBottom.addSubview(btnSession)
        
        btnProfile.frame = CGRect(x: self.view.frame.width-240+self.view.frame.width-250, y: 0, width: self.view.frame.width-250, height: 70)
        btnProfile.setTitle("Profile", for: .normal)
        btnProfile.addTarget(self, action: #selector(btnProfileClick), for: .touchUpInside) 
         btnProfile.backgroundColor = UIColor.clear
        
         btnProfile.contentVerticalAlignment = UIControl.ContentVerticalAlignment.bottom
        
        let imgViewJane = UIImageView()
            imgViewJane.frame = CGRect(x: 310, y: 10, width: 30, height: 35)
            imgViewJane.image = UIImage.init(named: "user023 - E183.png")
            buttonViewBottom.addSubview(imgViewJane)
        
        
         buttonViewBottom.addSubview(btnProfile)
        
        recordView.frame = CGRect(x: 0, y: 0, width: self.view.frame.width, height: self.view.frame.height-70)
        recordView.backgroundColor = UIColor.clear
        recordView.isHidden = false
        self.view.addSubview(recordView)
        
        let lblAppName = UILabel()
        lblAppName.frame = CGRect(x: 0, y: 20, width: GlobalVariables.Device_Width, height: 50)
        lblAppName.text = "Breathing APP"
        lblAppName.textColor = UIColor.white
        lblAppName.font = UIFont.boldSystemFont(ofSize: 25)
        lblAppName.textAlignment = .center
        recordView.addSubview(lblAppName)
        
        
        
        let lblRecod = UILabel()
        lblRecod.frame = CGRect(x: 0, y: 300, width: GlobalVariables.Device_Width, height: 50)
        lblRecod.textAlignment = .center
        lblRecod.text = "Records"
        lblRecod.textColor = UIColor.white
        recordView.addSubview(lblRecod)

        

        

        
       

        

        
        
      
      
        
        

        
        
        
     
        
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    //MARK: - All Buttons
@objc func btnrecordClick() 
    {
              
              
              

    
    }
    @objc func btnSessionClick()
    {
//        recordView.isHidden = true
     UIView .transition(with: self.view, duration: 0.5, options: .transitionFlipFromRight, animations:
                {
                    let svc = SessionVC()
                    self.navigationController?.pushViewController(svc, animated: true)
             
                   }, completion: {( finished: Bool ) -> () in
            })
    
    }
    @objc func btnProfileClick()
    {
//          recordView.isHidden = true
       UIView .transition(with: self.view, duration: 0.5, options: .transitionFlipFromRight, animations:
                  {
                      let Pvc = ProfileVC()
                      self.navigationController?.pushViewController(Pvc, animated: true)
               
                     }, completion: {( finished: Bool ) -> () in
              })
      
      }


    
}
        
        
        

   

 
    
    
    
    
    

